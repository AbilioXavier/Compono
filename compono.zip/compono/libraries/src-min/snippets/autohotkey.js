define("ace/snippets/autohotkey",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="autohotkey"});                (function() {
                    window.require(["ace/snippets/autohotkey"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            