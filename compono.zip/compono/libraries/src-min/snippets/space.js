define("ace/snippets/space",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="space"});                (function() {
                    window.require(["ace/snippets/space"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            