let elemBody = document.getElementsByTagName("body");

elemBody[0].onload(function () {
		//code goes here...
});