let pScrnShots = document.getElementsByTagName('img');

let imgPaths = [
    './media/images/bookPageA.JPG',
    './media/images/bookPageB.JPG',
    './media/images/bookPageC.JPG',
    './media/images/browser.JPG',
    './media/images/codeOverview.JPG',
    './media/images/codePreview.JPG',
    './media/images/codeSource.JPG',
    './media/images/eat.jpg',
    './media/images/forum.jpg',
    './media/images/logo.png',
    './media/images/project.jpg',
    './media/images/projectCollaborator.JPG',
    './media/images/screenshot1.JPG',
    './media/images/screenshot2.JPG',
    './media/images/screenshot3.JPG',
    './media/images/screenshot4.JPG',
    './media/images/whiteboard.jpg'
];

let a = 0;
let i = 0;

function changeImgSrc() {
    if (a < 17) {

        if (i < 4) {
            var el = pScrnShots[i];
        
            el.src = imgPaths[a];

            i++;
        } else {
            i = 0;
        }
        a++;
    } else {
        a = 0;
    }
}
setInterval(changeImgSrc, 2000);