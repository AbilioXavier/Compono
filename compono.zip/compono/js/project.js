var dom = require("ace/lib/dom");

class AcePlayground extends HTMLElement {
	constructor() {
		super();

		var shadow = this.attachShadow({ mode: "open" });

		var dom = require("ace/lib/dom");
		dom.builDom(["div", { id: "host" },
			["div", { id: "html" }],
			["div",]
		])
	}
}