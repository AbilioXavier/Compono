var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName('slide');
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
        slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 3000);
}

var style = document.createElement('style');
style.innerHTML = `
  body {
      background-image: url('./media/images/project.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
    }

    body>div {
      display: flex;
      align-self: center;
    }

    .box1 {
      box-sizing: border-box;
      height: 100vh;
      width: 50vw;
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      align-items: center;
      background-color: rgba(155, 155, 155, 0.4);
    }

    .box1-img>img {
      width: 100%;
      height: 100%;
    }

    .box1-lower {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-content: flex-start;
    }

    .social-icons,
    .contact-info {
      display: flex;
      justify-content: space-around;
    }

    footer {
      display: flex;
      flex-direction: row;
      justify-content: space-around;
      align-items: center;
      outline-offset: -10px;
      outline-color: lightgray;
      outline-style: groove;
    }

    footer a {
      text-decoration: none;
      color: whitesmoke;
    }
  `;
document.head.appendChild(style);